import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import folium
from flask import Flask, render_template

# Ensure plots folder exists
os.makedirs("static/plots", exist_ok=True)

app = Flask(__name__)

# Load and preprocess data (adjust preprocessing if columns like 'day', 'hour', 'age' need extraction)
data = pd.read_csv('FordGoBike_Final_Cleaned.csv')

# Preprocess if needed (example: assuming 'start_time' is a datetime column for day/hour; adjust as per your CSV)
# data['start_time'] = pd.to_datetime(data['start_time'])
# data['day'] = data['start_time'].dt.day_name()
# data['hour'] = data['start_time'].dt.hour
# data['age'] = 2023 - data['member_birth_year']  # Example age calculation; adjust

# Generate and save all plots (based on your code)
def generate_plots():
    # 1. Trips per Day (Bar Chart)
    plt.figure(figsize=(8, 5))
    data['day'].value_counts().sort_index().plot(kind='bar', color='skyblue')
    plt.title("Number of Trips per Day")
    plt.xlabel("Day")
    plt.ylabel("Number of Trips")
    plt.tight_layout()
    plt.savefig('static/plots/trips_per_day.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 2. User Type Distribution (Pie Chart)
    plt.figure(figsize=(6, 6))
    data['user_type'].value_counts().plot(kind='pie', autopct='%1.1f%%', startangle=90, colors=['#66b3ff', '#99ff99'])
    plt.title("User  Type Distribution")
    plt.ylabel("")
    plt.tight_layout()
    plt.savefig('static/plots/user_type_pie.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 3. Average Trip Duration by Gender (Bar Chart)
    plt.figure(figsize=(8, 5))
    data.groupby('member_gender')['trip_mins'].mean().plot(kind='bar', color=['#ff9999', '#66b3ff', '#99ff99'])
    plt.title("Average Trip Duration by Gender")
    plt.xlabel("Gender")
    plt.ylabel("Average Trip Duration (mins)")
    plt.tight_layout()
    plt.savefig('static/plots/trip_duration_gender.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 4. Trips by Hour of Day (Line Chart)
    plt.figure(figsize=(8, 5))
    data.groupby('hour').size().plot(kind='line', marker='o', color='orange')
    plt.title("Trips by Hour of Day")
    plt.xlabel("Hour")
    plt.ylabel("Number of Trips")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('static/plots/trips_by_hour.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 5. Trip Distance vs Duration (Scatter Plot)
    plt.figure(figsize=(7, 5))
    plt.scatter(data['distance_km'], data['trip_mins'], alpha=0.3, color='purple')
    plt.title("Trip Distance vs Duration")
    plt.xlabel("Distance (km)")
    plt.ylabel("Duration (mins)")
    plt.tight_layout()
    plt.savefig('static/plots/distance_vs_duration.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 6. Correlation Heatmap
    plt.figure(figsize=(6, 5))
    corr = data[['trip_mins', 'distance_km', 'age', 'hour']].corr()
    sns.heatmap(corr, annot=True, cmap='coolwarm', fmt='.2f')
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig('static/plots/correlation_heatmap.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 7. Trips Density by Day and Hour (Heatmap)
    pivot = data.pivot_table(index='day', columns='hour', values='duration_sec', aggfunc='count')
    plt.figure(figsize=(12, 6))
    sns.heatmap(pivot, cmap='YlGnBu')
    plt.title("Trips Density by Day and Hour")
    plt.tight_layout()
    plt.savefig('static/plots/trips_density_heatmap.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 8. Top 10 Start Stations (Bar Chart)
    top_stations = data['start_station_name'].value_counts().head(10)
    plt.figure(figsize=(10, 5))
    top_stations.plot(kind='bar', color='coral')
    plt.title("Top 10 Start Stations")
    plt.xlabel("Station")
    plt.ylabel("Number of Trips")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig('static/plots/top_stations.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 9. Age Distribution (Histogram)
    plt.figure(figsize=(8, 5))
    sns.histplot(data['age'], bins=30, kde=True, color='lightblue')
    plt.title("Age Distribution of Riders")
    plt.xlabel("Age")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig('static/plots/age_distribution.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 10. Folium Map (Start Stations)
    m = folium.Map(location=[37.77, -122.42], zoom_start=12)
    for _, row in data.sample(1000).iterrows():  # Sample for performance
        folium.CircleMarker(
            location=[row['start_station_latitude'], row['start_station_longitude']],
            radius=2, color='blue', fill=True, fill_opacity=0.5
        ).add_to(m)
    m.save('static/plots/map.html')

# Generate plots on startup
generate_plots()

@app.route('/')
def dashboard():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)